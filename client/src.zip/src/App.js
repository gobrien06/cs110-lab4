/*
Gabrielle O'Brien 862257027
Christopher Chen 862047098
*/

import { Chat } from "./pages/Chat";

const App = () => {
  return (
    <div className="App">
      <Chat />
    </div>
  );
};

export default App;
